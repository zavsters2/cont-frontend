// API Configuration
const API_BASE_URL = 'http://localhost:5001/api';

// State
let authToken = localStorage.getItem('authToken');
let currentUser = JSON.parse(localStorage.getItem('currentUser'));

// DOM Elements
const authSection = document.getElementById('auth-section');
const appSection = document.getElementById('app-section');
const userInfo = document.getElementById('user-info');
const userName = document.getElementById('user-name');
const logoutBtn = document.getElementById('logout-btn');

// Auth Elements
const loginTab = document.getElementById('login-tab');
const registerTab = document.getElementById('register-tab');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const loginError = document.getElementById('login-error');
const registerError = document.getElementById('register-error');

// Contact Form Elements
const contactForm = document.getElementById('contact-form');
const formTitle = document.getElementById('form-title');
const contactIdInput = document.getElementById('contact-id');
const contactNameInput = document.getElementById('contact-name');
const contactEmailInput = document.getElementById('contact-email');
const contactPhoneInput = document.getElementById('contact-phone');
const saveBtn = document.getElementById('save-btn');
const cancelBtn = document.getElementById('cancel-btn');
const formError = document.getElementById('form-error');

// Contact List Elements
const contactsLoading = document.getElementById('contacts-loading');
const contactsEmpty = document.getElementById('contacts-empty');
const contactsList = document.getElementById('contacts-list');

// Toast Element
const toast = document.getElementById('toast');

// ==================== API Functions ====================

async function apiRequest(endpoint, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers
  };

  if (authToken) {
    headers['Authorization'] = `Bearer ${authToken}`;
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.message || 'Request failed');
  }

  return data;
}

// Auth API
async function register(username, password) {
  const data = await apiRequest('/auth/register', {
    method: 'POST',
    body: JSON.stringify({ username, password })
  });
  return data;
}

async function login(username, password) {
  const data = await apiRequest('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username, password })
  });
  return data;
}

// Contacts API
async function getContacts() {
  return await apiRequest('/contacts');
}

async function createContact(contactData) {
  return await apiRequest('/contacts', {
    method: 'POST',
    body: JSON.stringify(contactData)
  });
}

async function updateContact(id, contactData) {
  return await apiRequest(`/contacts/${id}`, {
    method: 'PUT',
    body: JSON.stringify(contactData)
  });
}

async function deleteContact(id) {
  return await apiRequest(`/contacts/${id}`, {
    method: 'DELETE'
  });
}

// ==================== UI Functions ====================

function showToast(message, type = 'success') {
  toast.textContent = message;
  toast.className = `toast ${type}`;
  
  setTimeout(() => {
    toast.classList.add('hidden');
  }, 3000);
}

function setAuthState(isLoggedIn) {
  if (isLoggedIn && currentUser) {
    authSection.classList.add('hidden');
    appSection.classList.remove('hidden');
    userInfo.classList.remove('hidden');
    userName.textContent = `Welcome, ${currentUser.username}`;
    loadContacts();
  } else {
    authSection.classList.remove('hidden');
    appSection.classList.add('hidden');
    userInfo.classList.add('hidden');
  }
}

function switchAuthTab(tab) {
  if (tab === 'login') {
    loginTab.classList.add('active');
    registerTab.classList.remove('active');
    loginForm.classList.remove('hidden');
    registerForm.classList.add('hidden');
  } else {
    loginTab.classList.remove('active');
    registerTab.classList.add('active');
    loginForm.classList.add('hidden');
    registerForm.classList.remove('hidden');
  }
  loginError.textContent = '';
  registerError.textContent = '';
}

function resetContactForm() {
  contactForm.reset();
  contactIdInput.value = '';
  formTitle.textContent = 'Add New Contact';
  saveBtn.textContent = 'Save Contact';
  cancelBtn.classList.add('hidden');
  formError.textContent = '';
}

function editContact(contact) {
  formTitle.textContent = 'Edit Contact';
  saveBtn.textContent = 'Update Contact';
  cancelBtn.classList.remove('hidden');
  
  contactIdInput.value = contact.id;
  contactNameInput.value = contact.name || '';
  contactEmailInput.value = contact.email || '';
  contactPhoneInput.value = contact.phone || '';
  
  // Scroll to form
  document.querySelector('.contact-form-section').scrollIntoView({ behavior: 'smooth' });
}

function renderContacts(contacts) {
  contactsLoading.classList.add('hidden');
  
  if (contacts.length === 0) {
    contactsEmpty.classList.remove('hidden');
    contactsList.innerHTML = '';
    return;
  }
  
  contactsEmpty.classList.add('hidden');
  
  contactsList.innerHTML = contacts.map(contact => `
    <div class="contact-card" data-id="${contact.id}">
      <div class="contact-info">
        <div class="contact-name">${escapeHtml(contact.name)}</div>
        <div class="contact-details">
          ${contact.email ? `<div class="contact-detail"><strong>Email:</strong> ${escapeHtml(contact.email)}</div>` : ''}
          ${contact.phone ? `<div class="contact-detail"><strong>Phone:</strong> ${escapeHtml(contact.phone)}</div>` : ''}
        </div>
      </div>
      <div class="contact-actions">
        <button class="btn btn-secondary btn-small edit-btn" data-id="${contact.id}">Edit</button>
        <button class="btn btn-danger btn-small delete-btn" data-id="${contact.id}">Delete</button>
      </div>
    </div>
  `).join('');
  
  // Add event listeners for edit and delete buttons
  document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const contactId = parseInt(btn.dataset.id);
      const contact = contacts.find(c => c.id === contactId);
      if (contact) editContact(contact);
    });
  });
  
  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const contactId = btn.dataset.id;
      if (confirm('Are you sure you want to delete this contact?')) {
        try {
          await deleteContact(contactId);
          showToast('Contact deleted successfully');
          loadContacts();
        } catch (error) {
          showToast(error.message, 'error');
        }
      }
    });
  });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

async function loadContacts() {
  contactsLoading.classList.remove('hidden');
  contactsEmpty.classList.add('hidden');
  contactsList.innerHTML = '';
  
  try {
    const contacts = await getContacts();
    renderContacts(contacts);
  } catch (error) {
    contactsLoading.classList.add('hidden');
    showToast(error.message, 'error');
    
    // If unauthorized, log out
    if (error.message.includes('authorized')) {
      handleLogout();
    }
  }
}

function handleLogout() {
  authToken = null;
  currentUser = null;
  localStorage.removeItem('authToken');
  localStorage.removeItem('currentUser');
  setAuthState(false);
  resetContactForm();
  showToast('Logged out successfully');
}

// ==================== Event Listeners ====================

// Auth tabs
loginTab.addEventListener('click', () => switchAuthTab('login'));
registerTab.addEventListener('click', () => switchAuthTab('register'));

// Login form
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  loginError.textContent = '';
  
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;
  
  try {
    const data = await login(username, password);
    authToken = data.token;
    currentUser = { id: data.id, username: data.username };
    
    localStorage.setItem('authToken', authToken);
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    
    loginForm.reset();
    setAuthState(true);
    showToast('Login successful!');
  } catch (error) {
    loginError.textContent = error.message;
  }
});

// Register form
registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  registerError.textContent = '';
  
  const username = document.getElementById('register-username').value;
  const password = document.getElementById('register-password').value;
  
  try {
    const data = await register(username, password);
    authToken = data.token;
    currentUser = { id: data.id, username: data.username };
    
    localStorage.setItem('authToken', authToken);
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    
    registerForm.reset();
    setAuthState(true);
    showToast('Registration successful!');
  } catch (error) {
    registerError.textContent = error.message;
  }
});

// Logout
logoutBtn.addEventListener('click', handleLogout);

// Contact form
contactForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  formError.textContent = '';
  
  const contactData = {
    name: contactNameInput.value.trim(),
    email: contactEmailInput.value.trim() || null,
    phone: contactPhoneInput.value.trim() || null
  };
  
  const contactId = contactIdInput.value;
  
  try {
    if (contactId) {
      await updateContact(contactId, contactData);
      showToast('Contact updated successfully!');
    } else {
      await createContact(contactData);
      showToast('Contact created successfully!');
    }
    
    resetContactForm();
    loadContacts();
  } catch (error) {
    formError.textContent = error.message;
  }
});

// Cancel edit
cancelBtn.addEventListener('click', resetContactForm);

// ==================== Initialize ====================

// Check if user is already logged in
if (authToken && currentUser) {
  setAuthState(true);
} else {
  setAuthState(false);
}
